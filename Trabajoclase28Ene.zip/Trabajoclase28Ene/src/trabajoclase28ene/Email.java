/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trabajoclase28ene;

/**
 *
 * @author Maria Gabriela
 */
public class Email {
    // Atributos
    private String remitente;
    private String asunto;
    private String contenido;
    private boolean leido;
    
    //a. Constructor
    public Email(String remitente, String asunto, String contenido,boolean leido){
        this.remitente=remitente;
        this.asunto=asunto;
        this.contenido=contenido;
        this.leido=false;
    }
    
    //b.Funciones get
    public String getRemitente(){
        return remitente;
    }
    
     public String getAsunto(){
        return asunto;
    }
    
      public boolean getLeido(){
        return leido;
    }
      
      //c.Funcion leido
      public void leido(){
          this.leido=true;
      }
      
      //d. Funcion print
      public void  print(){
          System.out.println("DE: "+remitente);
          System.out.println("ASUNTO: "+ asunto);
          System.out.println("");
          System.out.println(contenido);
      }
      
    
}




