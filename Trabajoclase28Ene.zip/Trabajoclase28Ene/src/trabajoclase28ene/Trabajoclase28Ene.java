/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 * git remote add origin https://github.com/Maria-Rodriguez01/mariaclase.git
  git branch -M main
  git push -u origin main
 */
package trabajoclase28ene;

/**
 *
 * @author Maria Gabriela
 */
public class Trabajoclase28Ene {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    }
    

