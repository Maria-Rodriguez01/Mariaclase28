/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package trabajoclase28ene;

/**
 *
 * @author Maria Gabriela
 */
public class EmailAccount {
    //2a.Atributos
    //2b.Email y usuario
    public String emailacc;
    public String nombreu;
    //2c. Arreglo de 100 posiciones
    public Email[] inbox;

    //2d. Constructor
    public EmailAccount(String emailacc, String nombreu) {
        this.emailacc = emailacc;
        this.nombreu = nombreu;
        this.inbox = new Email[100];
    }

    //2e
    public boolean recibirEmail(Email em) {
        for (int i = 0; i < inbox.length; i++) {
            if (inbox[i] == null) {
                inbox[i] = em;
                return true;
            }
        }
        return false;
    }

    //2f. Funcion print inbox
    public void printInbox() {
        System.out.println("Correo de: " + nombreu + ". Direccion de correo: " + emailacc);
        int correosrecibidos = 0;
        for (int i = 0; i < inbox.length; i++) {
            if (inbox[i] != null) {
                System.out.println(i + (inbox[i].getLeido() ? "LEIDO": "SIN LEER") + " - " + " - " + inbox[i].print());
                correosrecibidos++;
            }
        }
        System.out.println("TOTAL de emails recibidos: " + correosrecibidos);
    }
    //2g.LEer email
    public void leerEmail(int posicion) {
        if (posicion < 0 || posicion >= inbox.length || inbox[posicion] == null) {
            System.out.println("Correo No Existe");
        } else {
            inbox[posicion].leido();
            inbox[posicion].print();
        }
    
}
    //2h. Borrar emails
    public void borrarLeidos() {
        for (int i = 0; i < inbox.length; i++) {
            if (inbox[i] != null && inbox[i].getLeido()) {
                inbox[i] = null;
            }
        }
    }
}
